﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HtmlAgilityPack;

namespace HAPtest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            HtmlAgilityPack.HtmlDocument getHtmlWeb = new HtmlAgilityPack.HtmlDocument();
            getHtmlWeb.LoadHtml(textBox1.Text);
            //richTextBox1.AppendText(document);

            //HtmlNode text = getHtmlWeb.DocumentNode.SelectNodes("//title");

            //HtmlAttribute att = text.InnerText;

            foreach (HtmlNode text in getHtmlWeb.DocumentNode.SelectNodes("//title"))
            {
                HtmlAttribute att = text.Attributes["title"];
                att.Value = FixLink(att);
            }
            doc.Save("file.htm");
        }

    }
}

    private List<string> GetTextFromArticle()
{

}

HtmlDocument doc = new HtmlDocument();
doc.Load("file.htm");
foreach (HtmlNode link in doc.DocumentNode.SelectNodes("//a[@href]"))
{
HtmlAttribute att = link.Attributes["href"];
att.Value = "http://www.google.com";
}
doc.Save("file.htm");